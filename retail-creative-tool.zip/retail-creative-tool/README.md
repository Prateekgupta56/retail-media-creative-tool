# Retail Creative Builder - Prototype

This is a minimal prototype project scaffold for the **Retail Creative Builder** demo.
It contains a simple frontend (React) and backend (FastAPI) with example endpoints and
three pre-made canvas JSONs using your uploaded asset.

**Uploaded asset included**: `assets/example_packshot.png` (sourced from the original upload).

## Contents
- `frontend/` - Minimal React app (uses Konva) to load canvas JSON and render.
- `backend/` - FastAPI app with endpoints:
  - `POST /api/assets/import`  - (demo) returns asset metadata
  - `POST /api/layouts/suggest` - returns the three ready-to-load canvas JSONs
  - `POST /api/validate` - returns a sample validation report
  - `POST /api/export` - stub for export (would perform server-side rendering/compression)
- `assets/` - Contains the provided packshot image.
- `canvas/` - Example canvas JSON files and ruleset.

## How to run (local dev)
### Backend (Python)
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend (React)
The frontend is a minimal React app scaffold. To run:
```bash
cd frontend
npm install
npm run dev
```
or serve the static files by your preferred method.

> Note: This scaffold is intended for local development and demo purposes. The backend contains stub implementations for background removal and export. Replace stubs with real services (rembg, Stable Diffusion, mozjpeg, S3 storage) in production.

